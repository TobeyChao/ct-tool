## 1. Baseline and delivery gates

- [ ] 1.1 Capture current Schema, Excel, JSON, FBS, Binary and C#/Lua outputs as migration fixtures, and verify the fixture export succeeds with `cd ct && pytest` plus a recorded full export.
- [ ] 1.2 Add a feature entry gate that keeps the production Schema module on the old read-only path until the new end-to-end apply test passes, and verify neither UI exposes two writable Schema flows simultaneously.
- [ ] 1.3 Define the v4 browser screenshot fixtures and viewport/zoom matrix in the test harness, and verify empty baseline captures can be produced for every required size.

## 2. Canonical Type Expression and named resources

- [ ] 2.1 Implement scalar/named/vector Type Expression models, parser and canonical serializer, and verify round-trip, reserved-name, malformed-expression and nested-vector unit tests.
- [ ] 2.2 Update FieldDef and all schema hashing/serialization paths to consume the Type Expression AST instead of mutually exclusive type fields, and verify model/hash tests cover every node kind.
- [ ] 2.3 Implement named Record and Enum models plus `config/types/*.yaml` repository loading/writing, and verify mixed Table/Record/Enum workspace fixtures load deterministically.
- [ ] 2.4 Introduce stable resource IDs, draft field IDs and canonical field paths without persisting UUID noise to YAML, and verify rename/move/path identity tests.
- [ ] 2.5 Add global name and generated FBS-name collision validation, and verify conflicts report both resource/field locations without traceback.
- [ ] 2.6 Update Workspace construction so CLI, Web, Excel, validation and generators receive one canonical resource graph, and verify no downstream module reparses raw type strings.

## 3. Dependencies, references and legacy migration

- [ ] 3.1 Extend dependency analysis to named Record/Enum edges and reverse references while retaining cross-table ref order, and verify direct, indirect, missing-target and deterministic-order tests.
- [ ] 3.2 Reject invalid dependency cycles and deletion of referenced resources/fields with complete paths, and verify direct/indirect cycle and multi-reference deletion tests.
- [ ] 3.3 Implement explicit resource/field rename commands that update all candidate references atomically, and verify undo plus old-path→new-path mapping tests.
- [ ] 3.4 Implement a dry-run legacy reader/migrator for inline enum/struct and array fields, including deterministic type-name allocation, and verify migrated YAML golden files.
- [ ] 3.5 Add ambiguous migration and collision failure reporting that leaves source files untouched, and verify failure-injection tests compare the entire workspace before/after.
- [ ] 3.6 Add one-time migration apply through the transaction mechanism and retire the writable legacy format after successful golden comparison, and verify old/new export parity where semantics are unchanged.

## 4. Excel layout and data migration

- [ ] 4.1 Implement canonical column layout generation for scalar, Enum, Record, single-cell vector and expanded `vector<Record>`, and verify path/order/header-depth unit tests.
- [ ] 4.2 Generate Excel headers from the layout model with aligned rich-text annotations matching the Web type expressions, and verify workbook render/golden tests.
- [ ] 4.3 Implement `cache/template_layouts/<table>.json` manifests tied to schema/layout revision, and verify create/read/corruption/missing-cache behavior.
- [ ] 4.4 Update the Excel reader to reconstruct Record and expanded `vector<Record>` values, skip fully empty trailing groups and retain exact row/column paths in issues, and verify reader tests.
- [ ] 4.5 Implement stable-path and explicit-rename column mapping for template updates, and verify reorder/rename/Record expansion tests never copy by raw column position.
- [ ] 4.6 Add data scans for deleted columns, `excel_columns` shrink, Enum value removal and type conversion, and verify blocking plans include concrete rows, columns and sample values.
- [ ] 4.7 Add legacy/untracked layout preflight with reviewable inference and no silent writeback, and verify missing-manifest workbooks cannot bypass review.

## 5. Export pipeline and query indexes

- [ ] 5.1 Update validation and JSON export for named Record/Enum and `vector<Record>`, and verify end-to-end parsed values and JSON golden output.
- [ ] 5.2 Update FBS generation so Record emits FlatBuffers table and vectors can reference Record/Enum, and verify generated schema compiles and contains no accidental native struct.
- [ ] 5.3 Update Binary serialization for Record and `vector<Record>`, and verify byte-level round trips against generated readers for empty, partial and full groups.
- [ ] 5.4 Update C# and Lua field accessors for the new type model, and verify both languages return the same Record/vector values and preserve i18n/server-only behavior.
- [ ] 5.5 Add table-level Code and Group index models plus Candidate data validation, and verify Code type/non-empty/uniqueness and Group repeated-value tests.
- [ ] 5.6 Generate symmetrical C#/Lua Code and Group APIs with deterministic missing and ordering semantics, and verify generated-code integration tests.
- [ ] 5.7 Implement hash buckets that retain normalized original strings and confirm equality after hash hits, and verify injectable-collision tests for hit, wrong-string and missing queries.
- [ ] 5.8 Add normal-bucket and adversarial-collision benchmarks proving original-value checks stay bucket-local, and record candidate comparisons and latency without a full-table scan.
- [ ] 5.9 Verify changing only separator or `excel_columns` leaves FBS/Binary/Accessor wire contracts unchanged while changing template hash and plan output.

## 6. Workspace Draft and Change Plan domain

- [ ] 6.1 Implement WorkspaceSnapshot revision hashing across managed Schema, type, Excel and generation inputs, and verify deterministic hashes plus external-change detection.
- [ ] 6.2 Define and implement the complete Draft command set and reducer with undo/redo cursor semantics, and verify add/delete/rename/move/property/index command tests.
- [ ] 6.3 Build Candidate Workspace from base revision plus commands and run full type/name/dependency/data/generator validation, and verify cross-resource errors block planning.
- [ ] 6.4 Implement Change Plan risk classification and per-artifact impact records for Schema, Excel, FBS, Binary and Accessors, and verify golden plans for safe, data-dependent, destructive, incompatible and dependency-breaking edits.
- [ ] 6.5 Add stable issue locations and “return to field/resource” identifiers to every plan problem, and verify Web API payloads never return only generic error strings.
- [ ] 6.6 Persist browser Drafts keyed by workspace and base revision, and verify refresh restores matching drafts while source changes produce an explicit stale/rebase-or-discard state.

## 7. Transactional Apply and Web API

- [ ] 7.1 Implement same-filesystem staging, workspace apply lock and plan manifest/token storage, and verify concurrent or expired plans are rejected before writes.
- [ ] 7.2 Generate all Candidate files in staging and run Schema reload, Excel reread, FBS/Binary and Accessor postchecks, and verify any generator failure prevents publish.
- [ ] 7.3 Implement durable journal, transaction backup and stepwise `os.replace` publishing, and verify successful apply yields one new revision and clears only applied Draft commands.
- [ ] 7.4 Implement startup recovery for interrupted publishing at every journal phase, and verify fault-injection tests recover a complete old or new revision, never a mixed set.
- [ ] 7.5 Add Workspace snapshot, validate, change-plan and apply endpoints using structured JSON and plan hashes, and verify API contract and stale-source tests.
- [ ] 7.6 Route legacy Schema read endpoints through WorkspaceSnapshot, remove direct writable endpoints after the v4 cutover, and verify production routes expose only one write protocol.
- [ ] 7.7 Surface long-running plan/apply progress and failures through persistent task state, and verify changing Web modules does not lose task status or actionable errors.

## 8. Web Panel foundation and design system

- [ ] 8.1 Split static CSS into token/base/layout/component/module layers using the approved forest-green palette and contrast values, and verify no production module defines duplicate brand/status colors.
- [ ] 8.2 Split frontend code into native ES module core, shared components and module boundaries without adding a build chain, and verify the packaged panel loads offline from the Python distribution.
- [ ] 8.3 Implement unified AppShell, top workspace header and desktop/mobile module navigation, and verify all five existing modules are reachable by keyboard and route.
- [ ] 8.4 Implement shared ModuleHeader, CommandBar, DataTable, Inspector, StatusBadge, InlineIssue, TaskBar, Dialog, Toast and EmptyState contracts, and verify component state fixtures.
- [ ] 8.5 Add shared API, error, task and focus management, and verify actionable errors persist while Toast remains limited to completed lightweight actions.
- [ ] 8.6 Add reduced-motion, visible-focus, contrast and hidden/inert accessibility rules, and verify automated checks plus keyboard traversal of shared fixtures.

## 9. Adaptive Schema workspace shell

- [ ] 9.1 Implement a route/store model for resource, tab, selection path, navigation stack, pane preferences and scroll positions independent of DOM visibility, and verify resize does not mutate domain state.
- [ ] 9.2 Implement `wide` three-pane projection at `>=1360px` with resizable resource and inspector areas, and verify widths persist by layout class without table misalignment.
- [ ] 9.3 Implement `medium` main+inspector projection with one temporary resource selector, and verify close leaves no strip, space, scrim or focusable hidden content.
- [ ] 9.4 Implement `<960px` resources→editor→properties page stack and `<600px` bottom module navigation, and verify application/system Back follows the expected hierarchy.
- [ ] 9.5 Implement Activity Tab `activeTool/null` behavior for side areas with clipped grid-track motion instead of off-screen translation, and verify collapsed inspector always has a restore control.
- [ ] 9.6 Implement compact field-row rendering and shared desktop table column templates, and verify 720×460 and 390×844 editing without global horizontal scroll or covered actions.

## 10. Schema editing experience

- [ ] 10.1 Implement Tables/Records/Enums resource pages and atomic resource switching, and verify title, metadata, tabs, content and inspector never show mixed resources.
- [ ] 10.2 Implement Table and Record field editors with add/delete/rename/reorder, type expression, roles and comments, and verify each action emits a Draft command rather than a file write.
- [ ] 10.3 Implement Enum value editing, wire-type display and reverse-reference navigation, and verify duplicate/empty/removal-with-data validation.
- [ ] 10.4 Implement the searchable type picker with base/Enum/Record groups and orthogonal single/vector toggle, and verify it cannot edit a named type inline or create nested vectors.
- [ ] 10.5 Implement field Inspector sections for ref, i18n, server_only, comment and Excel input layout, and verify illegal combinations show local and backend errors at the same path.
- [ ] 10.6 Implement Table query-index cards with generated API previews and data preflight summaries, and verify Records/Enums do not expose index controls.
- [ ] 10.7 Implement dependency/reference views and blocked delete/rename flows with navigation to each use site, and verify no cascade-delete path is available.
- [ ] 10.8 Implement Draft summary, undo/redo, reset-current-field, discard-all and “审查并应用” entry, and verify resource/pane/module navigation retains pending changes.
- [ ] 10.9 Implement Change Plan and Excel migration detail pages with grouped risks, path mapping, row samples and return-to-field actions, and verify primary Apply stays disabled for blockers.

## 11. Resource discovery and large-list behavior

- [ ] 11.1 Build the DOM-independent ResourceIndex and shared fuzzy scorer with highlighted match ranges, and verify abbreviations, multi-word queries, ties and deterministic ordering.
- [ ] 11.2 Implement left resource filtering with match/total counts, temporary search expansion, empty state and restored group preferences, and verify collapsed-group keyboard scenarios.
- [ ] 11.3 Implement `Cmd/Ctrl+P` Quick Open with recent resources, all-resource search, type disambiguation and full keyboard controls, and verify it works while the resource pane is absent.
- [ ] 11.4 Implement the shared fixed-row virtual list for resource tree and Quick Open with stable keys, overscan and accessible position metadata, and verify one rendering path is used at all item counts.
- [ ] 11.5 Run 100/1,000/10,000 resource benchmarks for first paint, input latency, scroll, DOM nodes and memory, and record acceptable thresholds plus any overscan tuning.

## 12. Existing module visual migration

- [ ] 12.1 Move Export into the shared shell/CommandBar/TaskBar while preserving current export/cancel behavior, and verify existing export API and tests remain unchanged.
- [ ] 12.2 Move i18n into shared DataTable/Inspector patterns with existing sync/status/compact semantics, and verify translation files and state counts are unchanged.
- [ ] 12.3 Move Logs to the shared full-width viewer and persistent issue details, and verify module/level/search filters plus links from task failures.
- [ ] 12.4 Move History to the shared module layout while retaining the backend’s latest-five limit, and verify record ordering and log navigation.
- [ ] 12.5 Remove duplicated module CSS, old top-level tabs and obsolete modal navigation only after parity tests pass, and verify no dead selectors, handlers or writable Schema routes remain.

## 13. End-to-end qualification and cutover

- [ ] 13.1 Add an end-to-end flow that migrates a legacy workspace, edits Table/Record/Enum and `vector<Record>`, configures indexes, reviews and atomically applies, and verify all YAML/Excel/JSON/FBS/Binary/C#/Lua outputs.
- [ ] 13.2 Add end-to-end stale-plan, blocked-reference, destructive-Excel and interrupted-publish cases, and verify every failure leaves the original workspace byte-for-byte consistent.
- [ ] 13.3 Execute the required viewport and 100%/125%/150% zoom screenshot matrix, and verify no pane strip, overlap, table header drift, clipped action or stale mixed-resource content.
- [ ] 13.4 Complete keyboard, focus restoration, reduced-motion and hidden/inert accessibility walkthroughs, and record fixes for every blocking issue.
- [ ] 13.5 Run the full `cd ct && pytest` suite, generated C#/Lua integration checks and performance baselines, and attach passing results to the change review.
- [ ] 13.6 Enable the v4 production entry, remove the temporary feature gate and migration-only writer, and verify a clean install plus packaged launcher workspace completes the same end-to-end flow.
