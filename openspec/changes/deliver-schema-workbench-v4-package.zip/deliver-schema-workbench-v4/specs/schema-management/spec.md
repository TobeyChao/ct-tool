## MODIFIED Requirements

### Requirement: Validate field type definitions
Schema 中每个字段 SHALL 声明可解析为 canonical Type Expression 的合法类型；首版支持 scalar、具名 Enum、具名 Record 与单层 vector 修饰，并支持可选 `i18n`、`ref`、`server_only`、comment 和 Excel 输入布局。旧 `array` 与表示 FlatBuffers table 的内联 `struct` SHALL 仅由迁移流程读取，不得作为新候选 Schema 写出。

#### Scenario: Invalid field type
- **WHEN** Schema 字段类型为未支持的 `integer`
- **THEN** 工具报错并指明文件、资源、字段和合法类型集合

#### Scenario: Valid named record vector
- **WHEN** 字段声明为 `vector<DropReward>` 且 DropReward 是工作区 Record
- **THEN** 工具成功解析为 canonical vector(named) 表达并建立命名依赖

#### Scenario: Nested vector rejected
- **WHEN** 字段声明为 `vector<vector<int32>>`
- **THEN** 工具在加载阶段拒绝并给出使用命名 Record 包装的修复提示

### Requirement: Validate enum field definitions
Enum SHALL 是具有非空值列表的具名工作区资源，每个值为合法且资源内唯一的标识符；字段 SHALL 通过 named Type Expression 引用 Enum。加载和 Candidate 校验 SHALL 在数据校验前完成资源存在性、重名和引用检查。

#### Scenario: Valid enum definition
- **WHEN** 工作区定义 ItemRarity 值 `[Common, Rare, Epic]` 且字段引用 ItemRarity
- **THEN** 工具成功加载并将字段解析为 named Enum 引用

#### Scenario: Empty enum values
- **WHEN** ItemRarity 定义空值列表
- **THEN** 工具在加载或 Candidate 阶段报错并定位 ItemRarity

#### Scenario: Enum data validation
- **WHEN** Excel 中字段填写 `Legendary` 但 ItemRarity 不包含该值
- **THEN** 校验报错并包含 Excel 行号、列、字段路径、当前值和允许值

### Requirement: Calculate maximum nesting depth
工具 SHALL 根据字段 Type Expression 与 Excel 输入布局计算模板头部所需深度。scalar、Enum 与单格 vector 深度为 1；展开 Record 的深度来自 Record 字段树；`vector<Record>` 展开模式 SHALL 在每个组下复用 Record 叶子路径。

#### Scenario: Flat table depth
- **WHEN** 所有字段均为 scalar、Enum 或单格 vector
- **THEN** `max_nesting_depth = 1` 且头部行数为 2

#### Scenario: Expanded record depth
- **WHEN** Table 含展开录入的 DropRange Record，Record 含 Min 与 Max scalar
- **THEN** 模板为资源字段、Record 叶子和注释生成所需层级，深度计算结果确定且可复现

#### Scenario: Vector record group depth
- **WHEN** `Rewards: vector<DropReward>` 使用展开模式且 `excel_columns: 3`
- **THEN** 三组共享相同的 Record 叶子深度，组数改变列数但不改变 canonical 运行时类型

## ADDED Requirements

### Requirement: Load named schema resources
工具 SHALL 从配置仓库加载 Table、Record、Enum 资源并构建一个 WorkspaceSnapshot；资源 ID、名称、来源文件和类型 SHALL 可稳定定位，重复名称或缺失来源 SHALL 在加载时报告。

#### Scenario: Load a mixed workspace
- **WHEN** 配置包含多个 Table、Record 和 Enum
- **THEN** WorkspaceSnapshot 包含全部资源及确定性顺序，字段命名引用可解析到唯一目标

### Requirement: Build workspace dependency and reverse-reference graph
工具 SHALL 同时分析 named 类型引用和跨表 `ref`，构建确定性的正向依赖与反向引用图；Candidate SHALL 拒绝失效目标、非法环和删除仍被引用的节点。

#### Scenario: Record dependency chain
- **WHEN** Item 引用 DropReward，DropReward 引用 ItemRarity
- **THEN** 图中存在对应依赖边，反向查询 ItemRarity 返回 DropReward 的精确字段路径

#### Scenario: Missing named target
- **WHEN** 字段引用不存在的 Reward
- **THEN** 加载或 Candidate 校验失败并定位引用字段与缺失名称

## REMOVED Requirements

### Requirement: Validate struct field definitions
**Reason**: 旧 `struct` 实际生成 FlatBuffers table，与 FlatBuffers native struct 语义冲突；可复用对象结构由具名 Record 替代。

**Migration**: 将内联 struct 提升为具名 Record，字段改为 named 引用；迁移必须分配无冲突名称并保持字段路径映射。native struct 不在本 change 内。

### Requirement: Validate array field definitions
**Reason**: 旧 `array` 表示的是 FlatBuffers vector，名称与目标格式冲突且不能承载统一命名类型引用。

**Migration**: 将 `array<T>` 迁移为 canonical `vector<T>`；separator 和 Excel 展开配置迁入字段输入布局，原有数据通过迁移 golden 验证。
