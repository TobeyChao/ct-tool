## Context

见 [proposal.md](./proposal.md)。当前项目是 Python `src` 布局，本地 Web Panel 由 Vue 3 全局脚本驱动、无前端构建链；Schema、Excel、FBS、Binary、C#/Lua Accessor 已有独立模块，但现有 canonical model 仍以字段内联 `enum/struct/array` 为中心，模板更新也缺少稳定列路径事务。

v4 原型与四份调研文档已经确定交互方向：稳定的资源/主区/检查器工作台、森林绿设计系统、3/2/1 栏投影、VS Code 式局部过滤与 Quick Open。旧 `bk` 只用于参考局部密度和问题样本，不作为实现骨架。实现必须兼容 launcher 的 `720×460` 最小窗口，并保持当前无构建、随 Python 包分发的部署方式。

## Goals / Non-Goals

**Goals:**

- 建立单一 Schema canonical model，让 Web、CLI、Excel、校验与全部生成器共享类型和索引语义。
- 让跨资源编辑成为可撤销、可审查、可恢复的 Workspace 事务。
- 以一个路由/状态模型投影桌面三栏、中屏两栏和窄屏页面栈，不为断点复制业务状态。
- 在不引入前端构建链的条件下拆分全局壳、共享组件与模块代码，并用可重复浏览器验收保护布局。
- 提供旧 Schema 到新模型的一次性、可验证迁移路径；迁移失败不得留下混合格式。

**Non-Goals:**

- 不实现 FlatBuffers native struct、异构 vector、嵌套 vector、cascade delete、任意复合索引或用户自定义 Accessor 名称。
- 不实现永久迁移历史/DSL、多人实时协作或远程锁；工作区仍是本机单用户模型，但会防御外部文件变化。
- 不引入完整 UI 框架、npm 打包器或运行时设计系统依赖。
- 不把依赖图可视化、收藏/标签管理和跨工作区字段搜索作为首版交付前置。

## Decisions

### 1. Canonical Type Expression 与 YAML/API 表达分层

后端 canonical model 使用递归 tagged union：

```text
ScalarType(name)
NamedType(resource_id, expected_kind=record|enum)
VectorType(element)
```

Web API 始终发送结构化 JSON，例如：

```json
{"kind":"vector","element":{"kind":"named","resourceId":"record:DropReward"}}
```

YAML 为了人工 diff 采用受控字符串：`int32`、`ItemRarity`、`vector<DropReward>`。加载器立即解析为 AST，保存器只从 AST 序列化字符串；scalar 名为保留字，Table/Record/Enum 名在统一命名域中校验，因此不存在靠字符串形状猜测类型的分支。

选择该方案而不是把每个 YAML type 写成嵌套对象，是为了保持配置可读、迁移 diff 紧凑；选择结构化 Web API 而不是让浏览器拼类型字符串，是为了让前端无权决定解析和序列化规则。

### 2. 资源存储与稳定标识

- Table 继续存放于 `config/schemas/*.yaml`，保持 Excel 文件、主键和表级索引归属。
- Record/Enum 存放于 `config/types/*.yaml`，每个文件包含 `kind`、`name` 与 fields/values；不再以内联定义复制到字段。
- 运行时稳定 ID 为带 kind 的标识（如 `table:Item`、`record:DropReward`、`enum:ItemRarity`），字段稳定路径为 `<resource-id>/<field-id>`。新资源和字段在 Draft 中先获得 UUID；名称不是内部选择 key。
- YAML 不需要保存 UUID；已落盘字段 ID 由资源 kind、来源文件和 canonical 路径确定性派生。显式 rename command 在同一事务内把旧 ID 映射到新 ID，避免把 rename 猜成删除+新增。

曾考虑统一迁入一个 `config/resources/` 目录，但这会同时破坏现有 CLI 路径约定和用户仓库结构，收益不足。

### 3. WorkspaceSnapshot、Draft command log 与前端持久化

后端提供只读 WorkspaceSnapshot，包含 revision/hash、资源、引用、模板状态和能力信息。前端 store 持有：

```text
baseRevision
commands[] / undoCursor
derivedDraft
route(resourceId, tab, selectionPath, stack)
panePreferences
recentResources
```

每次编辑追加具名 command（add/delete/rename/move/set property/set type/set index），undo/redo 只移动 cursor 并重新归约；不能用深拷贝最终 JSON 猜测用户意图。Draft 按工作区路径与 base revision 存入浏览器存储，刷新时仅在 revision 相同的情况下恢复；revision 不同则进入“源已变化”状态并要求丢弃或重新基于最新快照应用 command，不静默覆盖。

后端仍是所有校验与 apply 的权威。前端局部校验只用于即时反馈，不替代 Candidate 校验。

### 4. Workspace API 使用无服务器会话的 plan token

新增概念接口：

```text
GET  /api/schema-workspace
POST /api/schema-workspace/validate      {baseRevision, commands}
POST /api/schema-workspace/change-plan   {baseRevision, commands}
POST /api/schema-workspace/apply         {planId, baseRevision, candidateHash}
```

Change Plan 服务构建 Candidate、扫描 Excel、试生成必需产物并保存带过期时间的 plan manifest；大型 staged 文件放在工作区外的临时目录。Apply 不接受完整 Candidate 重新覆盖 plan，只接受 token 与 hash，避免“审查 A、应用 B”。旧 `/api/schemas` 读接口可在迁移期委托 Snapshot，直接写接口在前端切换后删除，不长期维持双写协议。

### 5. 逻辑原子发布使用 journal + 同文件系统 staging

普通文件系统不能对多个目录提供单条原子事务，因此这里的“原子”定义为：任何正常完成或恢复后的可观察 Workspace 都对应完整旧 revision 或完整新 revision，绝不长期暴露混合 revision。

流程：

1. 获取工作区 apply lock 并复核 base revision。
2. 在与目标同一文件系统创建受控 staging，生成完整 Candidate 文件集与 manifest。
3. 在 staging 运行 Schema 重载、Excel 复读、FBS/Binary 对拍和生成代码 postcheck。
4. 写 durable journal，记录旧/新 manifest、备份与发布阶段。
5. 将受影响文件移动到 transaction backup，再把 staged 文件以 `os.replace` 发布；每一步更新 journal。
6. 发布后从真实目标重新加载并核对 revision，成功才标记 committed 并清理临时文件。
7. 启动时若发现未完成 journal，按阶段完成发布或恢复 backup，再允许加载工作区。

这比逐文件直接写入复杂，但能满足跨 YAML、Excel 和 output 的事务语义。曾考虑只原子替换整个 `gd` 目录，但工作区可能很大且包含用户未纳入管理的文件，不可接受。

### 6. Excel 列路径 manifest 与迁移规划

模板继续在 Custom Document Properties 保存 `ct_schema_hash`、`ct_header_rows` 等摘要；完整列路径不塞进属性字符串，而写入 `cache/template_layouts/<table>.json`：

```text
layoutRevision
schemaHash
headerRows
columns[{index, stablePath, typeExpr, groupIndex?}]
```

Change Plan 以旧 layout manifest + 旧 SchemaSnapshot 和新 layout 生成映射；显式 rename command 优先，未改名同路径其次。对删除列、类型变化、Enum 值移除和 vector 组收缩扫描实际非空单元格。manifest 缺失或与 Excel hash 不匹配时不猜测为安全迁移，而是报告 legacy/untracked，并要求受控推断结果进入审查。

这种 sidecar 方案复用现有 cache 目录且不污染 Excel 可见 Sheet；代价是清缓存会失去自动精确迁移能力，因此 Change Plan 必须有明确降级状态。

### 7. Query index 以 hash bucket + 原值确认为正确性边界

Code 与 string Group 索引生成：

```text
hash -> candidate row index / candidate row indices
```

预加载时同时保留已物化的规范化原字符串。查询先算 hash，只遍历该桶，再逐个执行 ordinal 原字符串相等比较；不同字符串即使 hash 相同也绝不视为命中。Code 的预检仍拒绝相同原字符串，hash 相同但原文不同合法；Group 返回桶内所有原值相等的行。

额外比较的成本是 O(bucket size)，正常桶接近 O(1)，而不是 O(table size)。测试通过可注入 hash provider 构造碰撞，不依赖寻找真实算法碰撞。C# 与 Lua 必须使用同一规范化规则和 golden 数据。

### 8. ResourceIndex 与虚拟列表从第一天走单一路径

前端维护独立资源索引，不查询 DOM：规范化 label、kind、可选别名、稳定 ID、最近使用时间与搜索描述。局部过滤和 Quick Open 共享 fuzzy scorer 与命中位置，但拥有不同 scope 与呈现。

资源树先扁平化为 group header + visible resource rows，再由固定行高 windowed list 只渲染视口和 overscan；Quick Open 复用同一列表原语。不会在 `count > 200` 时切换实现。100/1,000/10,000 项基准记录首屏、查询响应、滚动、DOM 数与内存，结果只用于调节 overscan 和缓存，不改变行为契约。

### 9. 路由状态与布局投影完全分离

路由表达资源、页签、字段和 Change Plan：

```text
#/schema/resources
#/schema/<resource-id>?tab=fields
#/schema/<resource-id>/fields/<field-id>?panel=properties
#/schema/changes/review
```

AdaptiveWorkspace 只根据可用宽度计算 visible pages/panes。宽屏 pane 收起使用 activity tool 的 `activeTool/null`；中屏资源选择是唯一临时 overlay；`<960px` 通过页面栈条件渲染，不保留负位移的不可见 pane。断点变化不会修改 route、selection、Draft 或 scroll store。

字段列表在窄屏使用专用语义 row layout，不通过 CSS 把桌面五列表格压扁。需要跨行比较的索引与 diff 保留真正 table 并在自身容器滚动。

### 10. 无构建前端按 ES module 分层

静态资源拆为：

```text
styles/tokens.css, base.css, layout.css, components.css, modules/*.css
js/core/{api,store,router,task,focus}.js
js/components/*.js
js/modules/{export,i18n,schema,logs,history}/*.js
```

`index.html` 只加载入口 ES module 和共享样式。Vue 继续由现有分发方式提供，组件使用原生 module 导出；若目标内嵌浏览器验证不支持某项 module 能力，只允许在同一边界降级为显式 namespace，不回到单文件累加。设计 token 是唯一颜色/尺寸来源，原型 HTML 不进入生产包。

### 11. 分阶段交付但一次完成行为切换

实现顺序先建立 canonical model/迁移与事务后端，再建立 shell/store，最后接 Schema UI 和其他模块视觉迁移。功能可以在开发中受内部 flag 保护，但正式切换时旧写 API、旧表格 modal 与新 Draft 流程不能同时对用户可见，避免两套状态源。

## Risks / Trade-offs

- [Change 体量跨前后端和产物链，容易出现长期半成品] → 任务按 canonical model、事务、UI shell、Schema、全模块迁移和验收设置明确完成门；不开启生产入口直到端到端 apply 通过。
- [多文件发布无法获得内核级全局原子性] → 使用 lock、同文件系统 staging、durable journal、backup 和启动恢复，把逻辑原子性纳入故障注入测试。
- [清理 cache 后失去旧 Excel 精确路径 manifest] → 将状态显示为 untracked，生成可审查推断并阻止无法证明安全的自动搬移；绝不按列序静默处理。
- [大列表虚拟化影响读屏器集合语义和焦点] → 保存逻辑总数/位置语义、roving focus 和选中滚入视口，并以键盘/读屏验收覆盖过滤后焦点变化。
- [Type Expression YAML 字符串未来需要更多修饰符] → parser/AST 保持递归，YAML grammar 有版本与清晰错误；新增修饰符不要求下游改用字符串判断。
- [原字符串比较增加查询成本] → 只比较 hash 桶候选并缓存规范化字符串；基准覆盖正常和对抗桶，不以牺牲正确性换取理论常数。
- [统一视觉改版可能误改既有业务] → 导出、i18n、日志、历史先以现有 API 契约做行为回归，视觉迁移不得改变其文件写入和任务语义。
- [浏览器存储中的 Draft 与外部 Git/编辑器修改冲突] → Draft 绑定 base revision；不自动重放到未知快照，必须显式重新基于最新版本或丢弃。

## Migration Plan

1. 为现有配置和产物建立只读 fixture/golden，记录旧 Schema、Excel、JSON、FBS、Binary 与 Accessor 行为。
2. 实现新 AST、Record/Enum repository 和兼容读取器；旧 `array`/内联 `struct` 只在迁移入口解析，新 writer 只输出新格式。
3. 运行 dry-run 迁移：分配全局无冲突类型名、提升内联类型、转换 vector、生成旧/新字段路径和产物 diff；有歧义时停止并要求修复。
4. 在单个 journal 事务中备份并写入新 Schema/type 文件、layout manifest 与重新生成的模板/产物；全量回归通过后删除一次性迁移入口，不保留双格式编辑。
5. 上线 Workspace 读 API、Candidate/Change Plan/Apply 后端和故障恢复测试，再切换前端 Schema 模块。
6. 迁移 AppShell 和其余模块视觉；完成尺寸、缩放、键盘、截图和大列表基准后移除旧 modal/CSS/API。

回滚时关闭新入口，从最近 committed transaction backup 恢复受影响文件，并恢复上一版静态资源；由于旧 writer 不理解新格式，回滚必须同时恢复 Schema/type/Excel/output，不能只回退前端。
